package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Invoice;
import com.cg.service.InvoiceServiceImpl;

@RestController
public class Invoice_Calc_Controller {
	@Autowired
	InvoiceServiceImpl ser;
	
	
	@PostMapping(value = "/create", produces = "application/json", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Invoice createAccount(@RequestBody Invoice obj) {
		return ser.createInvoice(obj);
	}
	
	
	@PutMapping(value = "/update/{id}", produces = "application/json", consumes = MediaType.APPLICATION_JSON_VALUE)
	public Invoice updateInvoice(@RequestBody Invoice obj,@PathVariable int id) {
		return ser.updateInvoice(obj,id);
		
	}
	
	@DeleteMapping(value = "/delete/{id}")
	public String updateInvoice(@PathVariable int id) {
		 ser.deleteInvoice(id);
		 return "Deleted Invoice obj with id"+id;
		
	}
	
	@GetMapping(value = "/view")
	public List<Invoice> showAllInvoice() {
		
		 return  ser.viewAllInvoice();
	}
	
	@GetMapping(value = "/view/{id}")
	public Invoice viewById(@PathVariable int id) {
		
		 return  ser.findSingleInvoice(id);
	}


}
