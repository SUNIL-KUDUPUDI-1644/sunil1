package com.cg.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class RecepieRegPageFactory {
	
	
	
	WebDriver driver;
	
	@FindBy(how=How.ID,using="fname")
	@CacheLookup
	private WebElement firstName;

	//using how class
	@FindBy(how=How.ID, using="Submit1")
	@CacheLookup
	private WebElement confirmButton;

	@FindBy(how=How.ID,using="lname")
	@CacheLookup
	private WebElement lastName;
	
	@FindBy(how=How.NAME, using="email")
	@CacheLookup
	private WebElement email;

	@FindBy(how=How.NAME, using="mobile")
	@CacheLookup
	private WebElement mobileNo;
	
	@FindBy(how=How.NAME, using="D5")
	@CacheLookup
	private WebElement city;
	
	@FindBy(how=How.NAME, using="D6")
	@CacheLookup
	private WebElement category;

	@FindBy(xpath="/html/body/form/table/tbody/tr[8]/td[2]")
	@CacheLookup
	private WebElement mol;

	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]")
	@CacheLookup
	private WebElement iCD;
	
	@FindBy(how=How.NAME, using="enqdetails")
	@CacheLookup
	private WebElement yourEnquiry;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getConfirmButton() {
		return confirmButton;
	}

	public void setConfirmButton() {
		this.confirmButton.click();
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category.sendKeys(category);
	}

	public WebElement getMol() {
		return mol;
	}

	public void setMol(String mol) {
		this.mol.sendKeys(mol);
	}

	public WebElement getICD() {
		return iCD;
	}

	public void setICD(String iCD) {
		this.iCD.sendKeys(iCD);
	}

	public WebElement getYourEnquiry() {
		return yourEnquiry;
	}

	public void setYourEnquiry(String yourEnquiry) {
		this.yourEnquiry.sendKeys(yourEnquiry);
	}
	
	
	//initiating Elements
	public RecepieRegPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	
}
