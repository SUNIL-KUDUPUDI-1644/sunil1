package com.capg.ser;

import com.capg.model.Invoice;

public interface InvoiceService {
 

int calculateInvoice(Invoice i);
}
