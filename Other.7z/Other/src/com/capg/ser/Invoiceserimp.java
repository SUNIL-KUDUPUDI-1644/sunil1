package com.capg.ser;

import com.capg.dao.InvoiceRepo;
import com.capg.dao.Invoicerepoimp;
import com.capg.model.Invoice;

public class Invoiceserimp implements InvoiceService{

private InvoiceRepo i1 = new Invoicerepoimp();
	@Override
	public int calculateInvoice(Invoice i) {
     i.setAmount(((i.getDistance())/2)*i.getWeight());
     i.setCgst((i.getAmount()*3.5)/100);
     i.setSgst((i.getAmount()*3.5)/100);
     i1.saveInvoice(i);
	return 0;
	}
	

}
