package com.capg.dao;

import java.util.ArrayList;
import java.util.List;

import com.capg.model.Invoice;

public class Invoicerepoimp implements InvoiceRepo{
	Invoice i1 = new Invoice();
List<Invoice> l1 = new ArrayList<Invoice>();


	@Override
	public int saveInvoice(Invoice i) {
		l1.add(i);
		System.out.println(l1);
		return 0;
		
	}


	@Override
	public int saveInvoice() {
		// TODO Auto-generated method stub
		return 0;
	}}
