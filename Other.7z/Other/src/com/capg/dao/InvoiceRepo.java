package com.capg.dao;

import com.capg.model.Invoice;

public interface InvoiceRepo {
	int saveInvoice(Invoice i);

	int saveInvoice();

}
