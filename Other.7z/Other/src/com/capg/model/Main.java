package com.capg.model;

import java.util.Scanner;

import com.capg.ser.InvoiceService;
import com.capg.ser.Invoiceserimp;

public class Main {
	private static InvoiceService i1 = new Invoiceserimp(); 
	public static void main(String[] args) {
		Invoice i= new Invoice();
		Scanner sc = new Scanner(System.in);

		System.out.println("enter weight");
		i.setWeight(sc.nextInt());
		System.out.println("Enter Distance in km");
		i.setDistance(sc.nextInt());
		i.setId((int) ((Math.random() * ((9999 - 1000) + 1)) + 1000));
		i1.calculateInvoice(i);
		
		
	}

}
