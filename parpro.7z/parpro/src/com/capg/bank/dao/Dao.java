package com.capg.bank.dao;

import java.util.List;

import com.capg.bank.Bank;

public interface Dao {
	void createAccount(Bank b);
	Bank showBalance(int accNO);
	void deposit(int accNO, int amt);
	void withDraw(int accNO, int amt);
	void fundTransfer(int accNO, int accNOto, int amt);
	int checkAccno(int accno);
	int checkPass(String s);
	List<String> printTrans1(int accNO);

}
