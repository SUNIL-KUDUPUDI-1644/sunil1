package com.capg.bank.service;

import java.util.List;

import com.capg.bank.Bank;

public interface Service {
	void createAccount();

	Bank showBalance();

	void deposit();

	void withDraw();

	void fundTransfer();

	List<String> printTrans();

}
