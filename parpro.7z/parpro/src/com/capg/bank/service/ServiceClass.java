package com.capg.bank.service;

import java.util.List;
import java.util.Scanner;

import com.capg.bank.Bank;
import com.capg.bank.dao.Dao;
import com.capg.bank.dao.DaoClass;

public class ServiceClass implements Service {
	private Dao dao = new DaoClass();
	
   private Scanner sc = new Scanner(System.in);
   
	@Override
	public void createAccount() {
		Bank b = new Bank();
		int i;
		String name;
		System.out.println("\nEnter Your Details To Create Account :");
		do{
		System.out.println("Enter username");
		name=sc.next();
		i=b.setUserName(name);
		}
		while(i==1);
		b.setAccNo();
		b.setBalance();
		b.setPassword();
		
		dao.createAccount(b);
		
		
	}

	@Override
	public  Bank showBalance() {
		int i,k;
		int accNO;
		String pass;
		do{
		System.out.println("Enter Your Account No");
		accNO=sc.nextInt();
		i =dao.checkAccno(accNO);
		}
		while(i==1);
		do{
		System.out.println("Enter your password");
		pass=sc.next();
		k=dao.checkPass(pass);
		}
		while(k==1);
		return dao.showBalance(accNO);
	}

	@Override
	public void deposit() {
		int i,accNO;
		do{
		System.out.println("Enter The Account NO.");
		accNO= sc.nextInt();
		i=dao.checkAccno(accNO);
		}
		while(i==1);
		System.out.println("Enter Amount to be Deposited");
		int amt=sc.nextInt();
		dao.deposit(accNO,amt);
		
	}

	@Override
	public void withDraw() {
		int i,accNO,k;
		String pass;
		do{
		System.out.println("Enter The Account NO.");
		accNO= sc.nextInt();
		i=dao.checkAccno(accNO);
		}
		while(i==1);
		do{
			System.out.println("Enter your password");
			pass=sc.next();
			k=dao.checkPass(pass);
			}
			while(k==1);
		System.out.println("Enter Amount to be withdrawn");
		int amt=sc.nextInt();
		dao.withDraw(accNO,amt);
		
	}

	@Override
	public void fundTransfer() {
		int i,accNO,k;
		String pass;
		do{
		System.out.println("Enter The Account NO.");
		accNO= sc.nextInt();
		i=dao.checkAccno(accNO);
		}
		while(i==1);
		do{
			System.out.println("Enter your password");
			pass=sc.next();
			k=dao.checkPass(pass);
			}
			while(k==1);
		System.out.println("Enter Amount to be Transferred");
		int amt=sc.nextInt();
		System.out.println("Enter the Account No to be Transferrred");
		int accNOto= sc.nextInt();
		dao.fundTransfer(accNO,accNOto,amt);
		
	}

	@Override
	public List<String> printTrans() {
		int i,k;
		int accNO;
		String pass;
		do{
		System.out.println("Enter Your Account No");
		accNO=sc.nextInt();
		i =dao.checkAccno(accNO);
		}
		while(i==1);
		do{
		System.out.println("Enter your password");
		pass=sc.next();
		k=dao.checkPass(pass);
		}
		while(k==1);
		return(dao.printTrans1(accNO));
	}

	

}
