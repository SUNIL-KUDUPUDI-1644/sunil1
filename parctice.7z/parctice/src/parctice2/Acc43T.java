package parctice2;

import parctice.Access43;

public class Acc43T extends Access43 {
	
	public static void main(String[] args) {
		Access43 a = new Acc43T();
		//a.
	}

}
