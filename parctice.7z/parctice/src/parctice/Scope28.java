package parctice;

public class Scope28 {
	
	static int i;
	int j;
	public static void main(String[] args) {
	Scope28 sco =new Scope28();
	Scope28 sco1= new Scope28();
	sco.i=3;
	sco.j=4;
	sco1.i=5;
	sco1.j=6;
	System.out.println(sco.i+" "+sco.j+"  " +sco1.i+"  "+sco1.j);
	
	}

}
