package parctice;


class A{
	public A(){
		System.out.println("A ");
	}
}

class B extends A{
	public B(){
		System.out.println("B ");
	}
}
class Inherit27 extends B{
	public Inherit27(){
		System.out.println("c");
	}
	
	public static void main(String[] args) {
		Inherit27 c = new Inherit27();
	}
}
