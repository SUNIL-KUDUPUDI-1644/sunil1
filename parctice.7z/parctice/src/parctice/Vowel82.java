package parctice;

public class Vowel82 {
	private char var;
	public static void main(String[] args) {
		char var1='a';
		char var2=var1;
		var2='b';
		Vowel82 v= new Vowel82();
		v.var='i';
		Vowel82 v1 = v;
		v.var='s';
		System.out.println(v.var + " "+ v1.var);
	}

}
