package parctice;

public class Area68 {
	static double area;
	int b=2,h=4;
	public static void main(String[] args) {
		double p = 0,b = 0,h = 0;
		if(area==0) {
			b=3;
			h=4;
			p=0.5;
			
		}
		area=b*h*p;
		System.out.println(area);
	}

}
