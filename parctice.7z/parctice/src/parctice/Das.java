package parctice;

public class Das {
	public int getAmt() {
		return amt;
	}
	public void setAmt(int amt) {
		this.amt = amt;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	int amt;
	String name;
	public Das(String name){
		this.name=name;
	}
	public Das(int amt, String name) {
		this(name);
		this.amt = amt;
		
	}
	public static void main(String[] args) {
		Das d = new Das(12, "sun");
	}
	

}
