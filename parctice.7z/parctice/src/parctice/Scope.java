package parctice;
class Scope {
	double day;
}
