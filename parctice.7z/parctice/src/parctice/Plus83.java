package parctice;

public class Plus83 {
	public static void main(String[] args) {
		
		String names[] = {"Thomas","Peter","Joseph"};
		String pwd[] = new String[3];
		int idx=0;
		try {
			for(String n : names) {
				pwd[idx]=n.substring(2,6);
				idx++;
			}
			
		}
		catch (Exception e) {
			System.out.println("Invalid Name");
		}
		for(String p : pwd) {
			System.out.println(p);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		int a=9;
		StringBuilder s = new StringBuilder("asas");
		s.append("12234");
		String d=s.substring(1);
		d=d.concat("    mk   ");
		d=d.trim();
		System.out.println(s);
		System.out.println(d);
		if(a++<10) {
			System.out.println(a+"asd");
		}
		else {
			System.out.println("qwe");
		}
	}

}
