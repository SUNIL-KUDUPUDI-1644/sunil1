package parctice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//public class Test132 {
//	
//	String[] arr= {"HI","avb","aqwe","asasa"};
//	List<String> arrl= new ArrayList<>(Arrays.asList(arr));
//	if(arrl.removeIf((String s)->(return s.length()<=2;))) {
//		
//	}
//
//}
