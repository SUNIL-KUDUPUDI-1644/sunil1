package parctice;

public class Veh53 {
	int x;
	public Veh53() {
		this(10);
	}
	Veh53(int x){
		this.x=x;
	}

}
class Car extends Veh53{
	int y;
	Car(){
		super();
		//this(20);
	}
	Car(int y){
		this.y=y;
	}
}
