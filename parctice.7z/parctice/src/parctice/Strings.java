package parctice;

public class Strings {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder(5);
		String s="";
		if(sb.equals(s)) {
			System.out.println("MATCHED 1");
		}
		else if(sb.toString().equals(s)) {
			System.out.println("MATCHED 2");
		}
		else {
			System.out.println("NO MATCH");
		}
	}

}
