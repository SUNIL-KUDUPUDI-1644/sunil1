package parctice;

public class Test129 {
	int x,y;
	public Test129(int x,int y) {
		ini(x,y);
		
	}
	void ini(int x,int y) {
		this.x=x*x;
		this.y=y*y;
	}
	public static void main(String[] args) {
		int x=3;
		int y=5;
		Test129 obj = new Test129(3, 5);
		System.out.println(obj.x+"  "+obj.y);
	}

}
