package parctice;

public class Sa{
	public void updsco(Scope sco,double day) {
		day=day*2;
		sco.day=sco.day+day;
		
		System.out.println(day);
	}

	public static void main(String[] args) {
		Scope sco= new Scope();
		sco.day=200;
		double newday=100;
		Sa s = new Sa();
		s.updsco(sco, newday);
		System.out.println(sco.day);
		System.out.println(newday);
	}
	
}
