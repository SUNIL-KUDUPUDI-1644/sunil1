package parctice;

public class Pat89 {
	
	String name;

	public Pat89(String name) {
		this.name = name;
	}
	

}
