package parctice;

public class Str49 {

	
	public static void main(String[] args) {
		String str=" ";
		str.trim();
		System.out.println(str);
		System.out.println(str.equals(" ") + " " +str.isEmpty());
	}
}
