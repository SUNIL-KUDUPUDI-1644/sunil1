package parctice;

public class Str36 {
	public static void main(String[] args) {
		
	StringBuilder s = new StringBuilder("Bujji");
	String str = s.toString();
	//String str1 = s.toString();
	String str1="Bujji";
	String str2=str;
	System.out.println(str==str1);
	System.out.println(str==str2);
}}
