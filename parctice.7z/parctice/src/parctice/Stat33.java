package parctice;

public class Stat33 {

	static int count;
	public static void main(String[] args) {
		Stat331 s = new Stat331(50);
		Stat331 s1 = new Stat331(125);
		Stat331 s2 = new Stat331(100);
		s.dop();
		s1.dop();
		s2.dop();
		Stat331 sa = new Stat331();
		
		System.out.println("SA"+0+2);
		System.out.println("SA"+(1+2));
		
		sa.dm();
		sa.dm();
		
	}
	
	
}
