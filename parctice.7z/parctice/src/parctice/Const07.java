package parctice;

public class Const07 {
	String typ;
	int maxspd;
	public Const07(String typ, int maxspd) {
		this.typ = typ;
		this.maxspd = maxspd;
	}
	Const07(){
		
	}
	
}

