package parctice;

public class Das1 extends Das {

	public Das1(int amt, String name) {
		super(amt, name);
	}
	
	
	

}
