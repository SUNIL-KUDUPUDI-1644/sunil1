package parctice;

public class Ew {
public static void main(String[] args) {
	int[] sta= {10,20,30};
	int size=3;
	int idx=0;
	String str ="Hello World";
	str=str.trim();
	System.out.println(str.indexOf(" "));
	System.out.println(str);
	
	do {
		idx++;
	}while(idx<size-1);
	System.out.println(sta[idx]);
}
}
