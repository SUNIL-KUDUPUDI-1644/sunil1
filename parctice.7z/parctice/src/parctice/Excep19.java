package parctice;

public class Excep19 {
	
	void rC(int s) throws Exception{
		System.out.println("Reading Card");
	}
	void cC(int s) throws RuntimeException{
		System.out.println("cC");
	}

	
	public static void main(String[] args) {
		Excep19 e = new Excep19();
		int cd =122;
		e.cC(cd);
		try {
			e.rC(cd);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}
}
