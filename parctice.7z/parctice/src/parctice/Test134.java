package parctice;

public class Test134 {
	String name;

	public Test134(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Test134 [name=" + name + "]";
	}



}

