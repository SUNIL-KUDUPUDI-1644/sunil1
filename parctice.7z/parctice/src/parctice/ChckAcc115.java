package parctice;

public class ChckAcc115 {
int amt;


public static void main(String[] args) {
	ChckAcc115 c = new ChckAcc115();
	c.amt=100;
	System.out.println(c.amt);
	
	float var1=(12_345.01>=123_45.00)? 12_456 : 124_56.02f;
	float var2=var1+1024;
	System.out.println(var2);
	
}



}
