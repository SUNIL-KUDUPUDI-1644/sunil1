package parctice;

import java.util.ArrayList;

public class Excep45 {
	public static void main(String[] args) {
		
	ArrayList myList = new ArrayList();
	String[] myArry;
	try {
		while(true) {
			myList.add("MY STRING");
		}
	}
	catch(RuntimeException re) {
		System.out.println("Caught a Runtime Excep");
	}
	catch(Exception e) {
		System.out.println("Caught an excep");
	}
	System.out.println("ss");
}
}
