package parctice;
class Car extends Const07{
	String trans;
	Car(String trans){
		this.trans=trans;
		
	}
	Car(String type,int maxspd,String trans){
		super(type,maxspd);
		this.trans=trans;
		
	}
	
	
	public static void main(String[] args) {
		Car c = new Car("one");
		Car c1 = new Car("asa", 20, "asas");
		System.out.println(c.maxspd+"   "+c.trans.toString()+"    "+c.typ);
		System.out.println(c1.maxspd+"   "+c1.trans.toString()+"    "+c1.typ);
	}
}
	