package parctice;

public class Casting {
	public static void main(String[] args) {
		short i=200;
		long j=100+(long)i;
		int k=10;
		String s = String.valueOf(j);
		System.out.println(s);
	}
	
	

}
