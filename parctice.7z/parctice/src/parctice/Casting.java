package parctice;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class Casting {
	public static void main(String[] args) {
		short i=200;
		long j=100+(long)i;
		int k=10;
		String s = String.valueOf(j);
		System.out.println(s);
		
		
		
		
		
		ArrayList<Integer> points= new ArrayList<>();
		points.add(3);
		points.add(2);
		points.add(1);
		points.add(null);
		points.add(4);
		System.out.println(points);
		points.remove(2);
		points.remove(null);
		System.out.println(points);
		
		
		
		
		
		int[] nums= new int[2];
		
		nums[0]=1;
		nums[1]=2;
		nums = new int[4];
		nums[2]=3;
		nums[3]=4;
		
		for(int x:nums) {
			System.out.println(" "+x);
		}
		
		
		
		
		
		
		LocalDateTime dt=LocalDateTime.of(2014, 06, 30, 1, 1);
		dt.plusDays(3);
		dt.plusMonths(1);
		System.out.println(dt.format(DateTimeFormatter.ISO_DATE));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	

}
