package parctice;

public class Caller79 {
	
	private void init() {
		System.out.println("asdasd");
	}
	protected void start() {
		init();
		System.out.println("started");
	}

}
