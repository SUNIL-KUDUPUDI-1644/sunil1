package parctice;

public class SumTest96 {
	
	public static void dosum(Integer x,Integer y) {
		
		System.out.println("Integer sum is " + (x+y));
		
	}
public static void dosum(int x,int y) {
		
		System.out.println("Int sum is " + (x+y));
		
	}
public static void dosum(float x,float y) {
	
	System.out.println("Float sum is " + (x+y));
	
}
public static void dosum(double x,double y) {
	
	System.out.println("Double sum is " + (x+y));
	
}
public static void main(String[] args) {
	dosum(10, 20);
	dosum(10.0, 20.0);
}

}
