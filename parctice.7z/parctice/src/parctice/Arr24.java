package parctice;

public class Arr24 {
	
	public static void main(String[] args) {
		String[][] str = new String[2][];
		
		str[0]= new String[2];
		str[1] = new String[5];
		
		int i=97;
		System.out.println(str.length);
		for(int a=0;a<str.length;a++) {
			for(int b=0;b<str.length;b++) {
				System.out.println(a+" "+b);
				str[a][b]=""+i;
				i++;
			}
		}
		
		
		for(String[] ca:str) {
			for(String c:ca) {
				System.out.print(c+" ");
				
			}
			System.out.println();
		}
	}

}
