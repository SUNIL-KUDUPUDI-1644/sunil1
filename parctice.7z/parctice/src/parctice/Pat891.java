package parctice;

import java.util.ArrayList;
import java.util.List;

public class Pat891 {

	
	public static void main(String[] args) {
		List ls = new ArrayList();
		Pat89 p = new Pat89("Sun");
		ls.add(p);
		int f=ls.indexOf(p);
		System.out.println(f);
		
		
	}
}
