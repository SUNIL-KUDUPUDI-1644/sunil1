package parctice;

public class Arrsize57 {
	public static void main(String[] args) {
		int[][] sa = new int[1][3];
		
		System.out.println(sa.length);
		for(int i=0;i<sa.length;i++) {
			for(int j=0;j<sa[i].length;j++) {
				System.out.println(sa[i].length);
				sa[i][j]=10;
				System.out.println(sa[i][j]);
			}
		}
		
		
		
	}

}
