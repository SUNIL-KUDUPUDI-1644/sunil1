package parctice;

public class Teset79 {
		public static void main(String[] args) {
			Caller79 c = new Caller79();
			c.start();
		}

	}

