package parctice;



public class Myexcep71 {
	public static void main(String[] args) {
		try {
		meth1();
		}
		catch (Myexception e) {
			System.out.println("A");
		}
	}

	public static void meth1() {
		try {
			double a=Math.random();
			System.out.println(a);
			throw a>0.5 ? new Myexception() : new RuntimeException();
			
		}
		catch (RuntimeException re) {
			System.out.println("B");
		}
		
	}
}
