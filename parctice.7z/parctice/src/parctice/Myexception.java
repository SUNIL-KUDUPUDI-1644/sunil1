package parctice;

public class Myexception extends RuntimeException {

}
