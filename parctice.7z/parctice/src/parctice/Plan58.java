package parctice;

public class Plan58 {

	public String plan;
	public int moons;
	
	public Plan58(String plan, int moons) {
		this(plan);
		setMoons(moons);
	}
	
	

	public Plan58(String plan) {
		setPlan(plan);
	}



	public String getPlan() {
		return plan;
	}



	public void setPlan(String plan) {
		this.plan = plan;
	}



	public int getMoons() {
		return moons;
	}



	public void setMoons(int moons) {
		this.moons = moons;
	}



	@Override
	public String toString() {
		return "Plan58 [plan=" + plan + ", moons=" + moons + "]";
	}
	
	

	
	
}
