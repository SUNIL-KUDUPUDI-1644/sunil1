package parctice;

public class Dvd13 extends Bit13{
	int c;
	Dvd13(int r,int c){
		super(r);
		this.c=c;
	}
	public static void main(String[] args) {
		Dvd13 dvd = new Dvd13(10,20);
		System.out.println(dvd.c);
		System.out.println(dvd.r);
	}

}
