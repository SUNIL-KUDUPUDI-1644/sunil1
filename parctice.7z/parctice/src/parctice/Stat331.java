package parctice;

public class Stat331 {
	
	int j;
	int count;
	static int ja;
	public Stat331() {
		// TODO Auto-generated constructor stub
	}
	Stat331(int j){
		System.out.println(ja);
		if(ja<j) {
			ja=j;
			this.j=j;
		}
	}
	void dop() {
		System.out.println("j = " + j +"  ja =" + ja);
	}
	void dm() {
		System.out.println(count);
		count++;
		System.out.println(count);
	}

}



