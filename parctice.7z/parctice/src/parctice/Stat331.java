package parctice;

public class Stat331 {
	
	int j;
	static int ja;
	Stat331(int j){
		System.out.println(ja);
		if(ja<j) {
			ja=j;
			this.j=j;
		}
	}
	void dop() {
		System.out.println("j = " + j +"  ja =" + ja);
	}

}



