package parctice;


class Test1341{
	public static void main(String[] args) {
		Test134[] s = new Test134[3];
		s[1]= new Test134("2");
		s[2]= new Test134("3");
		for(Test134 t :s) {
			System.out.println(" " + t);
		}
		
	}
}//null