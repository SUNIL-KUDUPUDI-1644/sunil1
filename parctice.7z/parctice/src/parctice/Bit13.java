package parctice;

class Bit13 {
	
	int r;
	Bit13(int r){
		this.r=r;
	}

}
