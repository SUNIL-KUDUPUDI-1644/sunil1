package parctice;

class Bit13 {
	static char c;
	int r;
	Bit13(int r){
		this.r=r;
	}
	static void pri() {
		System.out.println(c);
	}

	public static void main(String[] args) {
		Bit13 d = new Bit13(10);
		d.pri();
	}
}
