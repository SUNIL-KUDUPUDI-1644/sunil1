package parctice;

public class Strings2 {
public static void main(String[] args) {
	String s="A ";
	s=s.concat("B ");
	String c ="C ";
	s=s.concat(c);
	s.replace('C', 'D');
	s=s.concat(c);
	System.out.println(s);
			
}
}
