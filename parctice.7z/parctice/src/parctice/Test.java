package parctice;
public class Test  
{ 
    public static void main(String[] args) 
    { 
    	int w=0;
        String[] str = { "two","one","three"};
        for(String s: str) {
        switch(s) 
        { 
        
            case "one": 
            case "two": 
            	w-=2;
            	System.out.println(w);
                System.out.println("two"); 
                break; 
            case "three": 
            	w-=1;
            	System.out.println(w);
                System.out.println("three"); 
                 
        } 
        }
    } 
} 