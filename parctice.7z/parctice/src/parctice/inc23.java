package parctice;

public class inc23 {
	public static void main(String[] args) {
	int x=100;
	System.out.println();
	}

}
