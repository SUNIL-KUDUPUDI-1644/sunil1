package parctice;

public class Plan581 {
	
	public static void main(String[] args) {
		Plan58[] plans = {new Plan58("asa",2),new Plan58("asaqwe",3),new Plan58("a",1)};
		
		System.out.println(plans);
		System.out.println(plans[2]);
		System.out.println(plans[2].moons);
		
	}

}
