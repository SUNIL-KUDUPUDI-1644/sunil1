package parctice;

public class ChckAcc17 {
	int amt;
	
	
	public ChckAcc17(int amt) {
		this.amt = amt;
	}


	public int getAmt() {
		return amt;
		
	}
	public void chngAmt(int x) {
		amt+=x;
		
	}
	
	public static void main(String[] args) {
		ChckAcc17 c = new ChckAcc17((int)(Math.random()*1000));
		c.chngAmt(-c.getAmt());
		System.out.println(c.getAmt());
	}

}
