package parctice;

public class Access43 {
	int p;
	private int q;
	protected int t;
	public int l;
	

}
